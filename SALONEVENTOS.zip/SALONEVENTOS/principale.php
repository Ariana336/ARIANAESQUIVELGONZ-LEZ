<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>MENU</title>
        <link rel="stylesheet" type="text/css" href="css1.css">
    </head>
    <body>
        <br>
             <fieldset>
                 <img src="imagen1.png" align="left" width="13%" height="22%">
                 <img src="imagen1.png" align="right" width="13%" height="22%">
                 <center><h1>Vestidos e Ilusiones<br></h1></center>
                 <form>
                    <div class="padre1">
                        <div class="boton"><input type="button" value="Calendario"  onclick="location.href='Calendario.php'"></div>
                        <div class="boton"><input type="button" value="Prenda" onclick="location.href='Prenda.php'"></div>
                        <div class="boton"><input type="button" value="Cliente"  onclick="location.href='Cliente.php'"></div>
                    </div>
                    <div class="padre1">
                    </div>
                    <div class="padre2">
                        <div class="boton"><input type="button" value="Inventario"  onclick="location.href='Inventario.php'"></div>
                    </div>
                    <div class="padre1">
                    </div>
                    <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Login" onclick="location.href='index.php'" >
                            </div>
                    </div>
                 </form>
             </fieldset>
    </center>
    </body>
</html>

