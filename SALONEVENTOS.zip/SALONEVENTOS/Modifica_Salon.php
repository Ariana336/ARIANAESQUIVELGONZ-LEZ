<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTROS INSERTA SALON</title>
        <link rel="stylesheet" type="text/css" href="registros.css">
    </head>
    <body>
<?php
        $host='localhost';
        $dbname='SALONDEEVENTOS';
        $username='sa';
        $pasword ='ari123';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname,
                          );  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}  

$tsql_callSP = "{call PROSALONES(?,?,?,?,?)}";
             $id_salon= $_POST['ID'];
             $nombre_salon= $_POST['nombre'];
             $capacidad= $_POST['capacidad'];
             $descripcion= $_POST['descripcion'];
             $precio= $_POST['precio'];
             $op="I";
           
             $params = array($id_salon, $nombre_salon, $capacidad,$descripcion, $precio,$op);  
  
/* Prepare and execute the query. */  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Row successfully inserted.\n";  
} else {  
    echo "Row insertion failed.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  
  $con= "SELECT * FROM SALONES";
$reg = sqlsrv_query($conn, $con);  
?>
<div class="datagrid">
<table>
<thead>
    <tr>
        <th>ID SALON</th>
        <th>NOMBRE</th>
        <th>CAPACIDAD</th>
        <th>DESCRIPCION</th>
        <th>PRECIO</th>
    </tr>
</thead>
<tbody>
    <?php
    
        
    
        while($row = sqlsrv_fetch_array($reg))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['ID_SALON'];
            echo "</td>";
            echo "<td>";
            echo $row['NOMBRE'];
            echo "</td>";
            echo "<td>";
            echo $row['CAPACIDAD'];
            echo "</td>";
            echo "<td>";
            echo $row['DESCRIPCION'];
            echo "</td>";
            echo "<td>";
            echo $row['PRECIO'];
            echo "</td>";
        }

    sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
</tbody>
</table>
</div>
    </body>
</html>