<?php
 $host='localhost';
        $dbname='ejemplo_login';
        $username='sa';
        $pasword ='ari123';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname);  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}  

$usuario= $_POST['usuario'];
$contraseña= $_POST['contraseña'];


$tsq_callSP = "SELECT*FROM usuario WHERE
                         username=(?) AND clave=(SELECT
                         dbo.fun_encriptar((?)))";
 $params = array($usuario,$contraseña);  
 $consulta = sqlsrv_query($conn, $tsq_callSP, $params);  
if(sqlsrv_fetch($consulta) === false) {
    die(print_r(sqlsrv_errors(), true));
}
$fila = sqlsrv_get_field($consulta,0);
$fila1 = sqlsrv_get_field($consulta,1);

if ($usuario =='user'){
    header("refresh:1; url=http://localhost/SALONEVENTOS/principal.php");
 
}
else
{
    echo"<h1> usuarios o contraseñas incorrectos</h1>";
    header("refresh:1; url=http://localhost/SALONEVENTOS/");
}
sqlsrv_free_stmt($consulta);  
sqlsrv_close($conn); 
