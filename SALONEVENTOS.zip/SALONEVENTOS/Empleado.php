<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <title>EMPLEADO</title>
<link type="text/css" rel="stylesheet" href="css_sub_menu.css">
</head>

<body>
    <br>
             <fieldset>
                 <img src="imagen1.png" align="left" width="13%" height="22%">
                 <img src="imagen1.png" align="right" width="13%" height="22%">
                 <center><h1>Empleado<br></h1></center>
                 <form>
                    <div class="padre1">
                        <div class="boton"><input type="button" value="Insertar un empleado"  onclick="location.href='F_Insertar_Empleado.php'"></div>
                        <div class="boton"><input type="button" value="Modificar un empleado" onclick="location.href='F_Modifica_Empleado.php'"></div>
                        <div class="boton"><input type="button" value="Eliminar un empleado"  onclick="location.href='F_Elimina_Empleado.php'"></div>
                    </div>
                    <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu" onclick="location.href='principal.php'" >
                            </div>
                    </div>
                 </form>
             </fieldset>
    </body>
</html>





