<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTROS MODIFICA CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="registros.css">
    </head>
    <body>
<?php
        $host='localhost';
        $dbname='SALONDEEVENTOS';
        $username='sa';
        $pasword ='ari123';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname,
                          );  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}  

$tsql_callSP = "{call PROCLIENTES(?,?,?,?,?,?,?,?,?)}";
             $id_cliente= $_POST['id'];
             $nombre_cliente= $_POST['nombre'];
             $calle= $_POST['calle'];
             $numero= $_POST['numero'];
             $estado= $_POST['estado'];
             $cp= $_POST['cp'];
             $telefono= $_POST['telefono'];
             $correo_electronico= $_POST['correo'];
             $op="M";
           
             $params = array($id_cliente, $nombre_cliente, $calle, $numero, $estado, $cp, $telefono,$correo_electronico,$op);  
  
/* Prepare and execute the query. */  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Row successfully inserted.\n";  
} else {  
    echo "Row insertion failed.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  
  $con= "SELECT * FROM CLIENTES";
$reg = sqlsrv_query($conn, $con);  
?>
<div class="datagrid">
<table>
<thead>
    <tr>
        <th>ID CLIENTE</th>
        <th>NOMBRE CLIENTE</th>
        <th>CALLE</th>
        <th>NUMERO</th>
        <th>ESTADO</th>
        <th>CP</th>
        <th>TELEFONO</th>
        <th>CORREO ELECTRONICO</th>
    </tr>
</thead>
<tbody>
    <?php
    
        
    
        while($row = sqlsrv_fetch_array($reg))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['ID_CLIENTE'];
            echo "</td>";
            echo "<td>";
            echo $row['NOMBRE_CLIENTE'];
            echo "</td>";
            echo "<td>";
            echo $row['CALLE'];
            echo "</td>";
            echo "<td>";
            echo $row['NUMERO'];
            echo "</td>";
            echo "<td>";
            echo $row['ESTADO'];
            echo "</td>";
            echo "<td>";
            echo $row['CP'];
            echo "</td>";
            echo "<td>";
            echo $row['TELEFONO'];
            echo "</td>";
            echo "<td>";
            echo $row['CORREO_ELECTRONICO'];
            echo "</td>";
        }

    sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
</tbody>
</table>
</div>
    </body>
</html>

