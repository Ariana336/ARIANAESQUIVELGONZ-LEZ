<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <title>Salones</title>
<link type="text/css" rel="stylesheet" href="css_sub_menu.css">
</head>

<body>
    <br>
             <fieldset>
                 <img src="imagen5.jpg" align="left" width="20%" height="20%">
                 <img src="imagen5.jpg" align="right" width="20%" height="20%">
                 <center><h1>Salones<br></h1></center>
                 <form>
                    <div class="padre1">
                        <div class="boton"><input type="button" value="Insertar un Salon"  onclick="location.href='F_Insertar_Salon.php'"></div>
                        <div class="boton"><input type="button" value="Modificar un Salon" onclick="location.href='F_Modifica_Salon.php'"></div>
                        <div class="boton"><input type="button" value="Eliminar un Salon"  onclick="location.href='F_Elimina_Salon.php'"></div>
                    </div>
                    <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu" onclick="location.href='principal.php'" >
                            </div>
                    </div>
                 </form>
             </fieldset>
</body>
</html>


