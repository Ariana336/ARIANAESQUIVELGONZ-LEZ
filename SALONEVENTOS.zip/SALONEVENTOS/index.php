<!DOCTYPE html>
<html>
<head>
<link type="text/css" rel="stylesheet" href="login.css">
 
<tittle></tittle>
</head>
<body>
	<div class="login">
	<h1>Iniciar Sesion</h1>
    <form method="post" action="control.php">
    	<input type="text" name="usuario" placeholder="Usuario" required="required" />
        <input type="password" name="contraseña" placeholder="Contraseña" required="required" />
        <button type="submit" class="btn btn-primary btn-block btn-large">Ingresar</button>
    </form>
</div>
</body>
</html>