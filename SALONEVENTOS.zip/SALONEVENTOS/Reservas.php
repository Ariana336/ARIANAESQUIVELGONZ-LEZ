
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <title>Reserva</title>
<link type="text/css" rel="stylesheet" href="css_sub_menu.css">
</head>

<body>
    <br>
             <fieldset>
                 <img src="imagen4.jpg" align="left" width="20%" height="20%">
                 <img src="imagen4.jpg" align="right" width="20%" height="20%">
                 <center><h1>Reserva<br></h1></center>
                 <form>
                    <div class="padre1">
                        <div class="boton"><input type="button" value="Insertar una reserva"  onclick="location.href='F_Insertar_reserva.php'"></div>
                        <div class="boton"><input type="button" value="Modificar una reserva" onclick="location.href='F_Modifica_reserva.php'"></div>
                        <div class="boton"><input type="button" value="Eliminar una reserva"  onclick="location.href='F_Elimina_reserva.php'"></div>
                    </div>
                    <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu" onclick="location.href='principal.php'" >
                            </div>
                    </div>
                 </form>
             </fieldset>
</body>
</html>


