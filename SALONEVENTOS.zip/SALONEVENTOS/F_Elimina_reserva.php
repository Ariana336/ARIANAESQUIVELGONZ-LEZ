<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>ELIMINAR RESERVA</title>
        <link rel="stylesheet" type="text/css" href="formularioe.css">
    </head>
    <body>
        <form action="EliminaReserva.php" method="post">
             <fieldset>
             <legend>Eliminar Reserva:<br></legend>
             <center>
                 <div class="boton">ID de Reserva:<input type="text" name="ID" required="required">
    <input type="submit" value="Enviar">
             </center>
             </fieldset>
         </form>
    </body>
</html>
