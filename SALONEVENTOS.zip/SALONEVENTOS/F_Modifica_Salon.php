<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title> MODIFICA SALON</title>
        <link rel="stylesheet" type="text/css" href="cssformulario2.css">
    </head>
    <body>
        <fieldset>
                 <img src="imagen4.jpg" align="left" width="20%" height="20%">
                 <img src="imagen4.jpg" align="right" width="20%" height="20%">
                 <center><h1>Modificar Salon<br></h1></center>
                 <form action="modificar_salon.php" method="post">
        <div class="padre1">
            <div class="boton">ID Salon: <input type="text" name="ID" required="required"><br>
            Nombre del Salon: <input type="text" name="nombre" required="required"><br>
    Capacidad: <input type="text" name="capacidad" required="required"><br>
    Descripcion: <input type="text" name="descripcion" required="required"><br>
    Precio: <input type="text" name="precio" required="required"><br>
            <div class="boton"><input type="submit" value="Enviar"></div>
        </div>
        <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu Inventario" onclick="location.href='Reservas.php'" >
                            </div>
        </div>    
    </form>
             </fieldset>
    </body>
</html>


