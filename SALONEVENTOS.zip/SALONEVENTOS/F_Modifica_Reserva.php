<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>MODIFICAR Rerserva</title>
        <link rel="stylesheet" type="text/css" href="cssformulario2.css">
    </head>
    <body>
        <fieldset>
                 <img src="imagen4.jpg" align="left" width="20%" height="20%">
                 <img src="imagen4.jpg" align="right" width="20%" height="20%">
                 <center><h1>Modificar Reserva<br></h1></center>
                 <form action="modificar_Reserva.php" method="post">
        <div class="padre1">
            <div class="boton">ID de Reserva:<input type="text" name="ID" required="required">
            <div class="boton">ID Evento: <input type="text" name="idevento" required="required"></div>
            <div class="boton">Salon ID: <input type="text" name="salonid" required="required"></div>
            <div class="boton"><input type="submit" value="Enviar"></div>
        </div>
        <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu" onclick="location.href='Principal.php'" >
                            </div>
        </div>    
    </form>
             </fieldset>
    </body>
</html>


