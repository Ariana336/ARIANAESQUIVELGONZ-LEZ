
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>MODIFICAR CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="cssformulario2.css">
    </head>
    <body>
             <fieldset>
                 <img src="imagen5.jpg" align="left" width="20%" height="20%">
                 <img src="imagen5.jpg" align="right" width="20%" height="20%">
                 <center><h1>Modificar Cliente<br></h1></center>
                 <form action="modificar_cliente.php" method="post">
        <div class="padre1">
            <div class="boton">ID del Cliente:<input type="text" name="id" required="required"><br>
                Nombre del Cliente: <input type="text" name="nombre" required="required"><br>
            Calle: <input type="text" name="calle" required="required"><br>
            Numero: <input type="text" name="numero" required="required"><br>
            Estado: <input type="text" name="estado" required="required"><br>
            CP: <input type="text" name="cp" required="required"><br>
            Telefono: <input type="text" name="telefono" required="required"><br>
            Correo Electronico: <input type="text" name="correo" required="required"><br>
            <center>
                <input type="submit" value="Enviar">
            </center>
            
            </div>
    
        </div>
        <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu Cliente" onclick="location.href='Clientes.php'" >
                            </div>
                            <div class="botonr">
                                <input  type="reset" value="Elimina Cliente" onclick="location.href='F_eliminar_cliente.php'" >
                            </div>
        </div>    
    </form>
             </fieldset>
         
    </body>
</html>
