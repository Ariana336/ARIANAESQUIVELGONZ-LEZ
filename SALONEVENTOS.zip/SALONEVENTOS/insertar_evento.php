<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTROS INSERTA EVENTO</title>
        <link rel="stylesheet" type="text/css" href="registros.css">
    </head>
    <body>
<?php
        $host='localhost';
        $dbname='SALONDEEVENTOS';
        $username='sa';
        $pasword ='ari123';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname,
                          );  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}  

$tsql_callSP = "{call PROEVENTOS(?,?,?,?,?)}";
             $id_EVENTO= '';
             $nombre= $_POST['nombre'];
             $descripcion= $_POST['descripcion'];
             $cliente_id= $_POST['cliente_id'];
             $op="I";
           
             $params = array($id_EVENTO, $nombre, $descripcion, $cliente_id,$op);  
  
/* Prepare and execute the query. */  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Row successfully inserted.\n";  
} else {  
    echo "Row insertion failed.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  
  $con= "SELECT * FROM EVENTOS";
$reg = sqlsrv_query($conn, $con);  
?>
<div class="datagrid">
<table>
<thead>
    <tr>
        <th>ID EVENTO</th>
        <th>NOMBRE</th>
        <th>DESCRIPCION</th>
        <th>CLIENTE_ID</th>
    </tr>
</thead>
<tbody>
    <?php
    
        
    
        while($row = sqlsrv_fetch_array($reg))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['ID_EVENTO'];
            echo "</td>";
            echo "<td>";
            echo $row['NOMBRE'];
            echo "</td>";
            echo "<td>";
            echo $row['DESCRIPCION'];
            echo "</td>";
            echo "<td>";
            echo $row['CLIENTE_ID'];
            echo "</td>";
        }

    sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
</tbody>
</table>
</div>
    </body>
</html>