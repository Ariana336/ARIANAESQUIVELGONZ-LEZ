<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>MENU</title>
        <link rel="stylesheet" type="text/css" href="css1.css">
    </head>
    <body>
        <br>
             <fieldset>
                 <img src="imagen5.jpg" align="left" width="20%" height="20%">
                 <img src="imagen5.jpg" align="right" width="20%" height="20%">
                 <center><h1>SALONES DE FIESTAS INFANTILES<br></h1></center>
                 <form>
                    <div class="padre1">
                        <div class="boton"><input type="button" value="Clientes"  onclick="location.href='Clientes.php'"></div>
                        <div class="boton"><input type="button" value="Eventos" onclick="location.href='Evento.php'"></div>
                        <div class="boton"><input type="button" value="Reserva"  onclick="location.href='Reservas.php'"></div>
                    </div>
                    <div class="padre1">
                    </div>
                    <div class="padre2">
                        <div class="boton"><input type="button" value="Salones"  onclick="location.href='Salones.php'"></div>
                    </div>
                    <div class="padre2">
                    </div>
                    <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Login" onclick="location.href='index.php'" >
                            </div>
                    </div>
                 </form>
             </fieldset>
    </body>
</html>

