<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>FORMULARIO INSERTA SALON</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
        <form action="Inserta_Salon.php" method="post">
             <fieldset>
             <legend>Ingresar nuevo Salon:<br></legend>
             <center>
    Nombre del Salon: <input type="text" name="nombre" required="required"><br>
    Capacidad: <input type="text" name="capacidad" required="required"><br>
    Descripcion: <input type="text" name="descripcion" required="required"><br>
    Precio: <input type="text" name="precio" required="required"><br>
    <input type="submit" value="Enviar">
             </center>
             </fieldset>
         </form>
    </body>
</html>

