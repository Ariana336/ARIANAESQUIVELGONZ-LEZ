<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>FORMULARIO INSERTA CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
        <form action="ingresar_cliente.php" method="post">
             <fieldset>
             <legend>Ingresar nuevo Cliente:<br></legend>
             <center>
    Nombre del Cliente: <input type="text" name="nombre" required="required"><br>
    Calle: <input type="text" name="calle" required="required"><br>
    Numero: <input type="text" name="numero" required="required"><br>
    Estado: <input type="text" name="estado" required="required"><br>
    CP: <input type="text" name="cp" required="required"><br>
    Telefono: <input type="text" name="telefono" required="required"><br>
    Correo Electronico: <input type="text" name="correo" required="required"><br>
    <input type="submit" value="Enviar">
             </center>
             </fieldset>
         </form>
    </body>
</html>


