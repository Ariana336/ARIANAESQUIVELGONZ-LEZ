<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTROS INSERTA CALENDARIO</title>
        <link rel="stylesheet" type="text/css" href="registros.css">
    </head>
    <body>
        <?php
        $host='localhost';
        $dbname='PROYECTOVI';
        $username='sa';
        $pasword ='123456';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname);  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}  

$tsql_callSP = "{call PROCALENDARIO(?,?,?,?)}";
             $id=$_POST['id'];
             $fecha_recepcion= $_POST['fecha_rep'];
             $fecha_entrega= $_POST['fecha_ent'];
             $op="M";
           
             $params = array($id, $fecha_recepcion, $fecha_entrega,$op);  
  
/* Prepare and execute the query. */  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Row successfully inserted.\n";  
} else {  
    echo "Row insertion failed.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  
 $con= "SELECT * FROM CALENDARIO";
$reg = sqlsrv_query($conn, $con);  
?>
<div class="datagrid">
<table>
<thead>
    <tr>
        <th>ID CALENDARIO</th>
        <th>FECHA RECEPCION</th>
        <th>FECHA ENTREGA</th>
    </tr>
</thead>
<tbody>
    <?php
    
        
    
        while($row = sqlsrv_fetch_array($reg))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['ID_C'];
            echo "</td>";
            echo "<td>";
            echo date_format($row['FECHA_RECEPCION'],'d-m-Y');
            echo "</td>";
            echo "<td>";
            echo date_format($row['FECHA_ENTREGA'],'d-m-Y');
            echo "</td>";
        }

    sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
</tbody>
</table>
</div>
    </body>
</html>


