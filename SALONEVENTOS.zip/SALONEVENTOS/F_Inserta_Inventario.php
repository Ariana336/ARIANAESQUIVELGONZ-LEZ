<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>INSERTAR CALENDARIO</title>
        <link rel="stylesheet" type="text/css" href="cssformulario1_P.css">
    </head>
    <body>
        <br>
             <fieldset>
                 <img src="imagen1.png" align="left" width="17%" height="25%" margin="5px">
                 <img src="imagen1.png" align="right" width="17%" height="25%">
                 <center><h1>Insertar Inventario<br></h1></center>
                 <form action="ingresar_calendario.php" method="post">
        <div class="padre1">
            <div class="boton"> Tipo de Inventario:<input type="text" name="tipo" required="required"></div>
            <div class="boton"><input type="submit" value="Enviar"></div>
        </div>
        <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu Inventario" onclick="location.href='Inventario.php'" >
                            </div>
        </div>    
    </form>
             </fieldset>
    </body>
</html>


