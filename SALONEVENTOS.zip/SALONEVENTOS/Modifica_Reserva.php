<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTROS INSERTA SALON</title>
        <link rel="stylesheet" type="text/css" href="registros.css">
    </head>
    <body>
<?php
        $host='localhost';
        $dbname='SALONDEEVENTOS';
        $username='sa';
        $pasword ='ari123';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname,
                          );  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}  

$tsql_callSP = "{call PRORESERVA(?,?,?,?)}";
             $id_reserva= $_POST['ID'];
             $id_evento= $_POST['idevento'];
             $salon_id= $_POST['salonid'];
             $op="M";
           
             $params = array($id_reserva, $id_evento, $salon_id,$op);  
  
/* Prepare and execute the query. */  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Row successfully inserted.\n";  
} else {  
    echo "Row insertion failed.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  
  $con= "SELECT * FROM RESERVA";
$reg = sqlsrv_query($conn, $con);  
?>
<div class="datagrid">
<table>
<thead>
    <tr>
        <th>ID RESERVA</th>
        <th>ID EVENTO</th>
        <th>SALON ID</th>
    </tr>
</thead>
<tbody>
    <?php
    
        
    
        while($row = sqlsrv_fetch_array($reg))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['ID_RESERVA'];
            echo "</td>";
            echo "<td>";
            echo $row['ID_EVENTO'];
            echo "</td>";
            echo "<td>";
            echo $row['SALON_ID'];
            echo "</td>";
        }

    sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
</tbody>
</table>
</div>
    </body>
</html>