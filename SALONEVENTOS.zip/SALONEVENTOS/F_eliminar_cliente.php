<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>ELIMINAR CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="cssformulario3.css">
    </head>
    <body>
             <fieldset>
                 <img src="imagen5.jpg" align="left" width="20%" height="20%">
                 <img src="imagen5.jpg" align="right" width="20%" height="20%">
                 <center><h1>Eliminar CLIENTE<br></h1></center>
                 <form action="eliminar_calendario.php" method="post">
        <div class="padre1">
            <div class="boton">ID del Cliente:<input type="text" name="ID" required="required"></div>
            <br>
            <div class="boton"><input type="submit" value="Enviar"></div>
        </div>
        <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu CLiente" onclick="location.href='Clientes.php'" >
                            </div>
                            <div class="botonr">
                                <input  type="reset" value="Inserta Evento" onclick="location.href='F_Insertar_evento.php'" >
                            </div>
        </div>    
    </form>
             </fieldset>
         
    </body>
</html>

