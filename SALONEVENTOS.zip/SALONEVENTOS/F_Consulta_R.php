<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CONSULTAS MULTITABLA</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ejecutar_consulta_r.php" method="post">
             <fieldset>
                 <legend>CONSULTAS RESUMEN<br></legend>
                 <center>
                     Consulta a ejecutar: <select name="consresumen[]" required="required" size="1"><br>
                         <option value="1">Consulta1</option>
                         <option value="2">Consulta2</option>
                         <option value="3">Consulta3</option>
                         <option value="4">Consulta4</option>
                         <option value="5">Consulta5</option>
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>


