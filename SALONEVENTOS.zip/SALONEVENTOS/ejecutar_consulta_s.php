<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTROS CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="registros.css">
    </head>
    <body>
    <?php
/* Specify the server and connection string attributes. */ 
    
        $host='localhost';
        $dbname='PROYECTOVI';
        $username='sa';
        $pasword ='123456';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname);  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}
$empresa = $post['consultae'];
echo $empresa;
$tsql_callSP = "{call CONSULTAS_SIMPLES( ?)}";
             $op= "D";
             $salesYTD = 0.0;
             $params = array($op);  
  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Row successfully inserted.\n";  
} else {  
    echo "Row insertion failed.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  

if($op == "A")
{
    $con1= "SELECT *FROM CS1";
    $reg1 = sqlsrv_query($conn, $con1);
    ?>
    <div class="datagrid">
    <table>
    <thead>
    <tr>
        <th>FOLIOP</th>
        <th>DEFECTOS</th>
        <th>ID_CALENDARIO</th>
    </tr>
    </thead>
    <tbody>
        <?php
    
        while($row = sqlsrv_fetch_array($reg1))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['FOLIOP'];
            echo "</td>";
            echo "<td>";
            echo $row['DEFECTOS'];
            echo "</td>";
            echo "<td>";
            echo $row['ID_CALENDARIO'];
            echo "</td>";
        } 
        sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>    
    
    <?php
}else if($op == 'B')
{
    $con2= "SELECT *FROM CS2";
    $reg2 = sqlsrv_query($conn, $con2);
    ?>
    <div class="datagrid">
    <table>
    <thead>
    <tr>
        <th>NUM_E</th>
        <th>AP_PATERNO</th>
        <th>SUELDO</th>
        <th>ID_PROPIETARIO</th>
    </tr>
    </thead>
    <tbody>
        <?php
    
        while($row = sqlsrv_fetch_array($reg2))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['NUM_E'];
            echo "</td>";
            echo "<td>";
            echo $row['AP_PATERNO'];
            echo "</td>";
            echo "<td>";
            echo $row['SUELDO'];
            echo "</td>";
            echo "<td>";
            echo $row['ID_PROPIETARIO'];
            echo "</td>";
        } 
        sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>

 <?php   
}else if($op == 'C')
{
    $con3= "SELECT *FROM CS3";
    $reg3 = sqlsrv_query($conn, $con3);
    ?>
    <div class="datagrid">
    <table>
    <thead>
    <tr>
        <th>ID_PROVEEDOR</th>
        <th>NOMBRE</th>
        <th>ESTADO</th>
        <th>TIPO</th>
    </tr>
    </thead>
    <tbody>
        <?php
    
        while($row = sqlsrv_fetch_array($reg3))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['ID_PROVEEDOR'];
            echo "</td>";
            echo "<td>";
            echo $row['NOMBRE'];
            echo "</td>";
            echo "<td>";
            echo $row['ESTADO'];
            echo "</td>";
            echo "<td>";
            echo $row['TIPO'];
            echo "</td>";
        } 
        sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>

    <?php
}else if($op == 'D')
{
    $con4= "SELECT *FROM CS4";
    $reg4 = sqlsrv_query($conn, $con4);
    ?>
    <div class="datagrid">
    <table>
    <thead>
    <tr>
        <th>ID_C</th>
        <th>FECHA_RECEPCION</th>
        <th>FECHA_RECEPCION</th>
    </tr>
    </thead>
    <tbody>
        <?php
    
        while($row = sqlsrv_fetch_array($reg4))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['ID_C'];
            echo "</td>";
            echo "<td>";
            echo date_format($row['FECHA_RECEPCION'],'d-m-Y');
            echo "</td>";
            echo "<td>";
            echo $row['FECHA_RECEPCION'];
            echo "</td>";
        } 
        sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>

    <?php
}



    
    

