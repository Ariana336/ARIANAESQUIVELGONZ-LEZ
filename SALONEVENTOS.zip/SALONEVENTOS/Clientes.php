
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CLIENTES</title>
    <link type="text/css" rel="stylesheet" href="css_sub_menu_1.css">
</head>

<body>
    <br>
             <fieldset>
                 <img src="imagen5.jpg" align="left" width="20%" height="20%">
                 <img src="imagen5.jpg" align="right" width="20%" height="20%">
                 <center><h1>CLIENTE<br></h1></center>
                 <form>
                    <div class="padre1">
                        <div class="boton"><input type="button" value="Ingresar en catalogo un nuevo cliente"  onclick="location.href='F_insertar_cliente.php'"></div>
                        <div class="boton"><input type="button" value="Modificar en catalogo un nuevo cliente" onclick="location.href='F_modificar_cliente.php'"></div>
                        <div class="boton"><input type="button" value="Eliminar en catalogo un nuevo cliente"  onclick="location.href='F_eliminar_cliente.php'"></div>
                    </div>
                    <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu" onclick="location.href='principal.php'" >
                            </div>
                    </div>
                 </form>
             </fieldset>
</body>
</html>



