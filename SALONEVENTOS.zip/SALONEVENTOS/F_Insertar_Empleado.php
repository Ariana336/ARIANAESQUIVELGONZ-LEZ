<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>INSERTAR CALENDARIO</title>
        <link rel="stylesheet" type="text/css" href="cssformulario1_P.css">
    </head>
    <body>
        <br>
             <fieldset>
                 <img src="imagen1.png" align="left" width="17%" height="25%" margin="5px">
                 <img src="imagen1.png" align="right" width="17%" height="25%">
                 <center><h1>Insertar Empleado<br></h1></center>
                 <form action="ingresar_calendario.php" method="post">
        <div class="padre1">
            <div class="boton">Nombre: <input type="text" name="nombre" required="required"></div>
            <div class="boton">Apellido Paterno: <input type="text" name="apellido_p" required="required"></div>
            <div class="boton">Apellido Materno: <input type="text" name="apellido_m" required="required"></div>
            <div class="boton">Numero de Telefono: <input type="text" name="telefono" required="required"></div>
            <div class="boton">Sueldo: <input type="text" name="Sueldo" required="required"></div>
            <div class="boton">Id Propietario: <input type="text" name="ID_Propi" required="required"></div>
            <div class="boton"><input type="submit" value="Enviar"></div>
        </div>
        <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu Empleado" onclick="location.href='Empleado.php'" >
                            </div>
        </div>    
    </form>
             </fieldset>
    </body>
</html>


