<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>ELIMINAR EMPLEADO</title>
        <link rel="stylesheet" type="text/css" href="cssformulario3.css">
    </head>
    <body>
             <fieldset>
                 <img src="imagen1.png" align="left" width="17%" height="25%" margin="5px">
                 <img src="imagen1.png" align="right" width="17%" height="25%">
                 <center><h1>Eliminar Empleado<br></h1></center>
                 <form action="modificar_empleado.php" method="post">
        <div class="padre1">
            <div class="boton">ID del empleado:<input type="text" name="ID" required="required"></div>
            <br>
            <div class="boton"><input type="submit" value="Enviar"></div>
        </div>
        <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu Empleado" onclick="location.href='Empleado.php'" >
                            </div>
        </div>    
    </form>
             </fieldset>
         
    </body>
</html>


