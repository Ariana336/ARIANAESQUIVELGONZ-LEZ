<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CONSULTAS_SIMPLES</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ejecutar_consulta_s.php" method="post">
             <fieldset>
                 <legend>CONSULTAS SIMPLES<br></legend>
                 <center>
                     Consulta a ejecutar: <select name="consultae" required="required" size="1"><br>
                         <option >Consulta1</option>
                         <option >Consulta2</option>
                         <option >Consulta3</option>
                         <option >Consulta4</option>
                         <option >Consulta5</option>
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>

<br>
        <br>
             <fieldset>
                 <img src="imagen1.png" align="left" width="17%" height="25%" margin="5px">
                 <img src="imagen1.png" align="right" width="17%" height="25%">
                 <center><h1>Insertar Cliente<br></h1></center>
                 <form action="ingresar_calendario.php" method="post">
        <div class="padre1">
            <div class="boton">Nombre: <input type="text" name="nombre" required="required"></div>
            <div class="boton">Apellido Paterno: <input type="text" name="apellido_p" required="required"></div>
            <div class="boton">Apellido Materno: <input type="text" name="apellido_m" required="required"></div>
            <div class="boton">Telefono: <input type="text" name="telefono" required="required"></div>
            <div class="boton">Folio de la prenda:  <input type="text" name="f_prenda" required="required"></div>
            <div class="boton"><input type="submit" value="Enviar"></div>
        </div>
        <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu Cliente" onclick="location.href='Cliente.php'" >
                            </div>
        </div>    
    </form>
             </fieldset>