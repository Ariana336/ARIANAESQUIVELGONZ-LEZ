<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTRAR EVENTO</title>
        <link rel="stylesheet" type="text/css" href="cssformulario1_p.css">
    </head>
    <body>            
        <fieldset>
                 <img src="imagen5.jpg" align="left" width="20%" height="20%">
                 <img src="imagen5.jpg" align="right" width="20%" height="20%">
                 <center><h1>Insertar EVENTO</h1></center>
                 <form action="modificar_evento.php" method="post">
        <div class="padre1">
            <div class="boton">ID del Evento:<input type="text" name="id" required="required"><br>
            <div class="boton">Nombre:<input type="text" name="nombre" required="required">
            <div class="boton">Descripcion:<input type="text" name="descripcion" required="required">
            <div class="boton">CLIENTE ID:<input type="text" name="cliente_id" required="required">
            <div class="boton"><input type="submit" value="Enviar">
        </div>
        <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Menu Evento" onclick="location.href='Evento.php'">
                            </div>
        </div>    
    </form>
             </fieldset>
    </body>
</html>


