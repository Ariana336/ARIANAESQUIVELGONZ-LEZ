<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>ELIMINA INVENTARIO</title>
        <link rel="stylesheet" type="text/css" href="formularioe.css">
    </head>
    <body>
        <form action="Elimina_Inventario.php" method="post">
             <fieldset>
             <legend>Elimina Inventario:<br></legend>
             <center>
                 Nombre inventario:<input type="text" name="nombre" required="required"><br>
                <input type="submit" value="Enviar">
             </center>
             </fieldset>
         </form>
    </body>
</html>

