<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>MENU</title>
        <link rel="stylesheet" type="text/css" href="css.css">
    </head>
    <body>
        <br>
             <fieldset>
                 <img src="imagen1.png" align="left" width="13%" height="22%">
                 <img src="imagen1.png" align="right" width="13%" height="22%">
                 <center><h1>BASE DE DATOS DISTRIBUIDAS<br></h1></center>
                 <form>
                    <div class="padre1">
                        <div class="boton"><input type="button" value="Consulta A"  onclick="location.href='F_Consulta1.php'"></div>
                        <div class="boton"><input type="button" value="Consulta B" onclick="location.href='F_Consulta2.php'"></div>
                        <div class="boton"><input type="button" value="Consulta C"  onclick="location.href='F_Consulta3.php'"></div>
                        <div class="boton"><input type="button" value="Consulta D"  onclick="location.href='F_Consulta4.php'"></div>
                    </div>
                    <div class="padre1">
                    </div>
                    <div class="padre2">
                        <div class="boton"><input type="button" value="Consulta E"  onclick="location.href='F_Consulta5.php'"></div>
                        <div class="boton"><input type="button" value="Consulta F"  onclick="location.href='F_Consulta6.php'"></div>
                        <div class="boton"><input type="button" value="Consulta G"  onclick="location.href='F_Consulta7.php'"></div>
                        <div class="boton"><input type="button" value="Consulta H"  onclick="location.href='F_Consulta8.php'"></div>
                    </div>
                    <div class="padre1">
                    </div>
                    <div class="padre3">
                        <div class="boton"><input type="button" value="Consulta I"  onclick="location.href='F_Consulta9.php'"></div>
                        <div class="boton"><input type="button" value="Consulta J"  onclick="location.href='F_Consulta10.php'"></div>
                    </div>
                    <div class="padre4">
                            <div class="botonr">
                                <input  type="reset" value="Login" onclick="location.href='index.php'" >
                            </div>
                    </div>
                 </form>
             </fieldset>
    </body>
</html>
