<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CONSULTAS_D</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ejecutar_consulta_sB.php" method="post">
             <fieldset>
                 <legend>CONSULTA D<br></legend>
                 <center>
                     Determinar si hay clientes de un territorio que se especifique como argumento de 
                     entrada,que realizan ordenes en territorios diferentes al que se encuentran.<br><br>
                     Categorias del producto: <select name="categoriap" required="required" size="1"><br>
                         <option value="A" >Bikes</option>
                         <option value="B">Components</option>
                         <option value="C">Clothing</option>
                         <option value="D">Accessories</option>
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>

