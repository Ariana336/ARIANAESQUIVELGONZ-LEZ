<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CONSULTAS_G</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ejecutar_consulta_sB.php" method="post">
             <fieldset>
                 <legend>CONSULTA G<br></legend>
                 <center>
                     Actualizar el correo electrónico de una cliente que se reciba como argumento en la instrucción de actualización.<br><br>
                     Categorias del producto: <select name="categoriap" required="required" size="1"><br>
                         <option value="A" >Bikes</option>
                         <option value="B">Components</option>
                         <option value="C">Clothing</option>
                         <option value="D">Accessories</option>
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>

