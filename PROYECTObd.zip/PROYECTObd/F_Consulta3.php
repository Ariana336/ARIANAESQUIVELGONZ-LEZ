<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CONSULTAS_C</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ejecutar_consulta_3.php" method="post">
             <fieldset>
                 <legend>CONSULTA C<br></legend>
                 <center>
                     Actualizar el stock disponible en un 5% de los productos de la categoría que se provea 
                     como argumento de entrada,en una localidad que también se provea como argumento de entrada 
                     en la instrucción de actualización.<br><br>
                     Categorias del producto: <select name="categoriap" required="required" size="1"><br>
                         <option value="1" >Bikes</option>
                         <option value="2">Components</option>
                         <option value="3">Clothing</option>
                         <option value="4">Accessories</option>
                         <br>
                           v: <select name="categoriap" required="required" size="1"><br>
                         
                         <br>
                     Categorias de la localidad: <select name="categoria1" required="required" size="1"><br>
                         <option value="1" >Tool Crib</option>
                         <option value="2">Sheet Metal Racks</option>
                         <option value="3">Paint Shop</option>
                         <option value="4">Paint Storage</option>
                         <option value="5">Metal Storage</option>
                         <option value="6">Miscellaneous Storage</option>
                         <option value="7">Finished Goods Storage</option>
                         <option value="10">Frame Forming</option>
                         <option value="20">Frame Welding</option>
                         <option value="30">Debur and Polish</option>
                         <option value="40">Paint</option>
                         <option value="45">Specialized Paint</option>
                         <option value="50">Subassembly</option>
                         <option value="60">Final Assembly</option>
                         
                         
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>

