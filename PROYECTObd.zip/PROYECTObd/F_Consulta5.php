<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CONSULTAS_E</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ejecutar_consulta_5.php" method="post">
             <fieldset>
                 <legend>CONSULTA E<br></legend>
                 <center>
                     Actualizar  la  cantidad  de  productos  de  una  orden  que  se  provea  como argumento en la instrucción de actualización.<br><br>
                     <div class="boton">Cantidad Producto:<input type="text" name="cant_prod" required="required">
                         <div class="boton">Id Orden:<input type="text" name="id_orden" required="required">
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>

