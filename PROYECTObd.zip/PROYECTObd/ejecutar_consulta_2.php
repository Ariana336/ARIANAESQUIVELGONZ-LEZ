<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTROS CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="registros.css">
    </head>
    <body>
    <?php
/* Specify the server and connection string attributes. */ 
    
        $host='localhost';
        $dbname='AdventureWorks2019';
        $username='sa';
        $pasword ='ari123';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname);  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}
//$empresa = $post['consultae'];
//echo $empresa;
$tsql_callSP = "{call CONSULTAS_SIMPLES( ?)}";
             $op=$_POST['categoriap'];       
             $salesYTD = 0.0;
             $params = array($op);  
  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Consulta ejecutada exitosamente.\n"; 
    echo $op;
} else {  
    echo "Consulta ejecutada sin exito.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  

if($op == 'A')
{
    $con1= "SELECT *FROM CSA";
    $reg1 = sqlsrv_query($conn, $con1);
    ?>
    <div class="datagrid">
    <table>
    <thead>
    <tr>
        <th>territoryID</th>
        <th>Total_Ventas</th>
    </tr>
    </thead>
    <tbody>
        <?php
    
        while($row = sqlsrv_fetch_array($reg1))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['TerritoryID'];
            echo "</td>";
            echo "<td>";
            echo $row['Total_Ventas'];
            echo "</td>";
        } 
        sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>    
    
    <?php
}else if($op == 'B')
{
    $con1= "SELECT *FROM CSB";
    $reg1 = sqlsrv_query($conn, $con1);
    ?>
    <div class="datagrid">
    <table>
    <thead>
    <tr>
        <th>territoryID</th>
        <th>Total_Ventas</th>
    </tr>
    </thead>
    <tbody>
        <?php
    
        while($row = sqlsrv_fetch_array($reg1))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['TerritoryID'];
            echo "</td>";
            echo "<td>";
            echo $row['Total_Ventas'];
            echo "</td>";
        } 
        sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>    
    
    <?php
}else if($op == 'C')
{
    $con1= "SELECT *FROM CSC";
    $reg1 = sqlsrv_query($conn, $con1);
    ?>
    <div class="datagrid">
    <table>
    <thead>
    <tr>
        <th>territoryID</th>
        <th>Total_Ventas</th>
    </tr>
    </thead>
    <tbody>
        <?php
    
        while($row = sqlsrv_fetch_array($reg1))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['TerritoryID'];
            echo "</td>";
            echo "<td>";
            echo $row['Total_Ventas'];
            echo "</td>";
        } 
        sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>    
    
    <?php
}else if($op == 'D')
{
    $con1= "SELECT *FROM CSA";
    $reg1 = sqlsrv_query($conn, $con1);
    ?>
    <div class="datagrid">
    <table>
    <thead>
    <tr>
        <th>territoryID</th>
        <th>Total_Ventas</th>
    </tr>
    </thead>
    <tbody>
        <?php
    
        while($row = sqlsrv_fetch_array($reg1))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['TerritoryID'];
            echo "</td>";
            echo "<td>";
            echo $row['Total_Ventas'];
            echo "</td>";
        } 
        sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
    </tbody>
    </table>
    </div>
    </body>
</html>    
    
    <?php
}



    
    

