<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CONSULTAS_I</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ejecutar_consulta_sB.php" method="post">
             <fieldset>
                 <legend>CONSULTA I<br></legend>
                 <center>
                     Determinar paraun rango de fechas establecidas como argumento de entrada,cual es el total de
                     las ventas en cada una de las regiones.<br><br>
                     Categorias del producto: <select name="categoriap" required="required" size="1"><br>
                         <option value="A" >Bikes</option>
                         <option value="B">Components</option>
                         <option value="C">Clothing</option>
                         <option value="D">Accessories</option>
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>

