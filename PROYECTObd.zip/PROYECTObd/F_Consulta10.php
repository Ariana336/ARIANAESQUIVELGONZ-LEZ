<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CONSULTAS_J</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ejecutar_consulta_sB.php" method="post">
             <fieldset>
                 <legend>CONSULTA J<br></legend>
                 <center>
                     Determinar los 5 productos menos vendidos en un rango de fecha establecido como argumento de entrada.<br><br>
                     Categorias del producto: <select name="categoriap" required="required" size="1"><br>
                         <option value="A" >Bikes</option>
                         <option value="B">Components</option>
                         <option value="C">Clothing</option>
                         <option value="D">Accessories</option>
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>

