<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CONSULTAS_A</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ejecutar_consulta_s.php" method="post">
             <fieldset>
                 <legend>CONSULTA A<br></legend>
                 <center>
                     Determinar el total de las ventas de los productos de la categoría que se provea como argumento de entrada 
                     en la consulta,para cada uno de los territorios registrados en la base de datos o para cada una de las 
                     regiones (atributo groupde SalesTerritory)según se especifique como argumento de entrada.<br><br>
                     Categorias del producto: <select name="categoriap" required="required" size="1"><br>
                         <option value="A" >Bikes</option>
                         <option value="B">Components</option>
                         <option value="C">Clothing</option>
                         <option value="D">Accessories</option>
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>
