<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTRAR PRENDA</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="insertar_prenda.php" method="post">
             <fieldset>
                 <legend>Insertar prenda:<br></legend>
                 <center>
    Color:<input type="text" name="color" required="required"><br>
    Tipo: <input type="text" name="tipo" required="required"><br>
    Defectos: <input type="text" name="defectos" required="required"><br>
    Talla: <input type="text" name="talla" required="required"><br>
    Marca: <input type="text" name="marca" required="required"><br> 
    Id del calendario:  <input type="text" name="id_calendario" required="required"><br>
    <input type="submit" value="Enviar">
                 </center>
             </fieldset>
         </form>
    </body>
</html>