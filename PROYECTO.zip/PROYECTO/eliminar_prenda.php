<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTROS CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="registros.css">
    </head>
    <body>
    <?php
/* Specify the server and connection string attributes. */ 
    
        $host='localhost';
        $dbname='PROYECTOVI';
        $username='sa';
        $pasword ='123456';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname);  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}  

$tsql_callSP = "{call PROPRENDA( ?, ?,?,?,?,?,?,? )}";
             $foliop= $_POST['fp'];
             $color= '';
             $tipo= '';
             $defectos= '';
             $talla= '';
             $marca='';
             $id_calendario='';
             $op="E";
             $params = array($foliop, $color, $tipo, $defectos, $talla, $marca, $id_calendario, $op);  
  
/* Prepare and execute the query. */  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Row affected.\n";  
} else {  
    echo "Row insertion failed.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  
$con= "SELECT * FROM PRENDA";
$reg = sqlsrv_query($conn, $con);  
?>
<div class="datagrid">
<table>
<thead>
    <tr>
        <th>FOLIO PRENDA</th>
        <th>COLOR</th>
        <th>TIPO</th>
        <th>DEFECTOS</th>
        <th>TALLA</th>
        <th>MARCA</th>
        <th>ID CALENDARIO</th>
    </tr>
</thead>
<tfoot>
    <tr>
        <td colspan="4"><div id="paging"><ul><li><a href="#"><span>Previous</span></a></li><li>
                        <a href="#" class="active"><span>1</span></a></li><li><a href="#"><span>2</span></a></li><li><a href="#"><span>3</span></a></li>
                    <li><a href="#"><span>4</span></a></li><li><a href="#"><span>5</span></a></li><li><a href="#"><span>Next</span></a></li></ul></div>
    </tr>
</tfoot>
<tbody>
    <?php

    
        while($row = sqlsrv_fetch_array($reg))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['FOLIOP'];
            echo "</td>";
            echo "<td>";
            echo $row['COLOR'];
            echo "</td>";
            echo "<td>";
            echo $row['TIPO'];
            echo "</td>";
            echo "<td>";
            echo $row['DEFECTOS'];
            echo "</td>";
            echo "<td>";
            echo $row['TALLA'];
            echo "</td>";
            echo "<td>";
            echo $row['MARCA'];
            echo "</td>";
            echo "<td>";
            echo $row['ID_CALENDARIO'];
            echo "</td>";
        }

    sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
</tbody>
</table>
</div>
    </body>
</html>
