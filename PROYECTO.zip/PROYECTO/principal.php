
<!DOCTYPE html>
<html>
<head>
<link type="text/css" rel="stylesheet" href="principal.css">
 
<tittle></tittle>
</head>

<body>
    <div class="login">
    <h1><center>VESTIDOS E ILUSIONES</center></h1>
   
</div>
    <button  class="btn btn-primary btn-block btn-large" onclick="location.href='http://localhost/PROYECTO/F_insertar_calendario.php'">Ingresar en calendario nuevo pedido</button><br>
    <button  class="btn btn-primary btn-block btn-large" onclick="location.href='http://localhost/PROYECTO/F_modificar_calendario.php'">Modificar en calendario un pedido</button><br>
    <button  class="btn btn-primary btn-block btn-large" onclick="location.href='http://localhost/PROYECTO/F_eliminar_calendario.php'">Eliminar en calendario un pedido</button><br>
    <button  class="btn btn-primary btn-block btn-large" onclick="location.href='http://localhost/PROYECTO/F_Insertar_prenda.php'">Insertar prenda de un pedido</button><br>
    <button  class="btn btn-primary btn-block btn-large" onclick="location.href='http://localhost/PROYECTO/F_modificar_prenda.php'">Modificar prenda de un pedido</button><br>
    <button  class="btn btn-primary btn-block btn-large" onclick="location.href='http://localhost/PROYECTO/F_eliminar_prenda.php'">Eliminar prenda de un pedido</button><br>
    <button  class="btn btn-primary btn-block btn-large" onclick="location.href='http://localhost/PROYECTO/F_Insertar_cli.php'">Insertar un cliente</button><br>
    <button  class="btn btn-primary btn-block btn-large" onclick="location.href='http://localhost/PROYECTO/F_modificar_cliente.php'">Modificar un cliente</button><br>
    <button  class="btn btn-primary btn-block btn-large" onclick="location.href='http://localhost/PROYECTO/F_eliminar_cliente.php'">Eliminar un cliente</button><br>

</body>
</html>

