<html>
    <head>
        <meta charset="UTF-8">
        <title>REGISTROS CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="registros.css">
    </head>
    <body>
    <?php
/* Specify the server and connection string attributes. */ 
    
        $host='localhost';
        $dbname='PROYECTOVI';
        $username='sa';
        $pasword ='123456';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname);  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}  

$tsql_callSP = "{call PROCLIENTE( ?, ?,?,?,?,?,? )}";
             $id='';
             echo "valor de id =", $id;
             $nombre= $_POST['nombre'];
             $apellidopaterno= $_POST['apellido_p'];
             $apellidomaterno= $_POST['apellido_m'];
             $numerotelefono= $_POST['telefono'];
             $folio=$_POST['f_prenda'];
             $op="I";
             $salesYTD = 0.0;
             $params = array($id, $nombre, $apellidopaterno, $apellidomaterno, $numerotelefono, $folio,$op);  
  
/* Prepare and execute the query. */  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Row successfully inserted.\n";  
} else {  
    echo "Row insertion failed.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  

$con= "SELECT * FROM CLIENTE";
$reg = sqlsrv_query($conn, $con);  
?>
<div class="datagrid">
<table>
<thead>
    <tr>
        <th>ID CLIENTE</th>
        <th>NOMBRE</th>
        <th>APELLIDO PATERNO</th>
        <th>APELLIDO MATERNO</th>
        <th>NUMERO TELEFONO</th>
        <th>FOLIO PRENDA</th>
    </tr>
</thead>
<tfoot>
    <tr>
        <td colspan="4"><div id="paging"><ul><li><a href="#"><span>Previous</span></a></li><li>
                        <a href="#" class="active"><span>1</span></a></li><li><a href="#"><span>2</span></a></li><li><a href="#"><span>3</span></a></li>
                    <li><a href="#"><span>4</span></a></li><li><a href="#"><span>5</span></a></li><li><a href="#"><span>Next</span></a></li></ul></div>
    </tr>
</tfoot>
<tbody>
    <?php

    
        while($row = sqlsrv_fetch_array($reg))
        {
            echo "<tr>";
            echo "<td>";
            echo $row['ID_CLIENTE'];
            echo "</td>";
            echo "<td>";
            echo $row['NOMBRE'];
            echo "</td>";
            echo "<td>";
            echo $row['AP_PATERNO'];
            echo "</td>";
            echo "<td>";
            echo $row['AP_MATERNO'];
            echo "</td>";
            echo "<td>";
            echo $row['NUM_TELEFONO'];
            echo "</td>";
            echo "<td>";
            echo $row['FOLIO_PRENDA'];
            echo "</td>";
        }

    sqlsrv_free_stmt($stmt);  
    sqlsrv_close($conn);  
    ?>
</tbody>
</table>
</div>
    </body>
</html>



