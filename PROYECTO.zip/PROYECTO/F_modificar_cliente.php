<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>MODIFICAR CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="formulariom.css">
    </head>
    <body>
        <form action="modificar_cliente.php" method="post">
             <fieldset>
             <legend>Modificar cliente:<br></legend>
             <center>
    ID del cliente:<input type="text" name="ID" required="required"><br>
    Nombre: <input type="text" name="nombre" required="required"><br>
    Apellido Paterno: <input type="text" name="apellido_p" required="required"><br>
    Apellido Materno: <input type="text" name="apellido_m" required="required"><br>
    Telefono: <input type="text" name="telefono" required="required"><br> 
    Folio de la prenda:  <input type="text" name="f_prenda" required="required"><br>
    <input type="submit" value="Enviar">
             </center>
             </fieldset>
         </form>
    </body>
</html>