<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>ELIMINAR CALENDARIO</title>
        <link rel="stylesheet" type="text/css" href="formularioe.css">
    </head>
    <body>
        <form action="eliminar_calendario.php" method="post">
             <fieldset>
                 <legend>Eliminar calendario:<br></legend>
                 <center>
    ID del cliente:<input type="text" name="ID" required="required"><br>
    <input type="submit" value="Enviar">
                 </center>
             </fieldset>
         </form>
    </body>
</html>

