<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>FORMULARIO INSERTA CLIENTE</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
        <form action="Insertar_cliente.php" method="post">
             <fieldset>
             <legend>Ingresar nuevo cliente:<br></legend>
             <center>
    Nombre: <input type="text" name="nombre" required="required"><br>
    Apellido Paterno: <input type="text" name="apellido_p" required="required"><br>
    Apellido Materno: <input type="text" name="apellido_m" required="required"><br>
    Telefono: <input type="text" name="telefono" required="required"><br> 
    Folio de la prenda:  <input type="text" name="f_prenda" required="required"><br>
    <input type="submit" value="Enviar">
             </center>
             </fieldset>
         </form>
    </body>
</html>


