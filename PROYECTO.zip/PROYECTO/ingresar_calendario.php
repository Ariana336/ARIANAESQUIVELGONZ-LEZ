<?php
        $host='localhost';
        $dbname='PROYECTOVI';
        $username='sa';
        $pasword ='123456';
$connectionInfo = array( "UID"=>$username,  
                         "PWD"=>$pasword,  
                         "Database"=>$dbname);  
  
/* Connect using SQL Server Authentication. */  
$conn = sqlsrv_connect( $host, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true)); 
}  

$tsql_callSP = "{call PROCALENDARIO(?,?,?,?)}";
             $id= '';
             $fecha_recepcion= $_POST['fecharep'];
             $fecha_entrega= $_POST['fechaent'];
             $op="I";
           
             $params = array($id, $fecha_recepcion, $fecha_entrega,$op);  
  
/* Prepare and execute the query. */  
$stmt = sqlsrv_query($conn, $tsql_callSP, $params);  
if ($stmt) {  
    echo "Row successfully inserted.\n";  
} else {  
    echo "Row insertion failed.\n";  
    die(print_r(sqlsrv_errors(), true));  
}  
  
/* Free statement and connection resources. */  
sqlsrv_free_stmt($stmt);  
sqlsrv_close($conn);

