<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>ELIMINAR PRENDA</title>
        <link rel="stylesheet" type="text/css" href="formularioe.css">
    </head>
    <body>
        <form action="eliminar_prenda.php" method="post">
             <fieldset>
                 <legend>Eliminar prenda:<br></legend>
                 <center>
    Folio de la Prenda:<input type="text" name="fp" required="required"><br>
    <input type="submit" value="Enviar">
                 </center>
             </fieldset>
         </form>
    </body>
</html>
