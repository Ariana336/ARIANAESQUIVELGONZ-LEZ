<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>INGRESAR AL CALENDARIO NUEVO PEDIDO</title>
        <link rel="stylesheet" type="text/css" href="formulario.css">
    </head>
    <body>
         <form action="ingresar_calendario.php" method="post">
             <fieldset>
                 <legend>Ingresar en calendario nuevo pedido:<br></legend>
                 <center>
    Fecha de recepcion: <input type="text" name="fecharep" required="required"><br>
    Fecha de entrega: <input type="text" name="fechaent" required="required"><br> 
    <input type="submit" value="Enviar">
     </center>
             </fieldset>
         </form>
     </body>
</html>