<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>MODIFICAR CALENDARIO</title>
        <link rel="stylesheet" type="text/css" href="formulariom.css">
    </head>
    <body>
        <form action="modificar_calendario.php" method="post">
             <fieldset>
                 <legend>Modificar calendario:<br></legend>
                 <center>
    ID del calendario:<input type="text" name="id" required="required"><br>
    Fecha de recepcion: <input type="text" name="fecha_rep" required="required"><br>
    Fecha de entrega: <input type="text" name="fecha_ent" required="required"><br>
    <input type="submit" value="Enviar">
                 </center>
             </fieldset>
         </form>
    </body>
</html>