<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>MODIFICAR PRENDA</title>
        <link rel="stylesheet" type="text/css" href="formulariom.css">
    </head>
    <body>
        <form action="modificar_prenda.php" method="post">
             <fieldset>
                 <legend>Modificar prenda:<br></legend>
                 <center>
    Folio de la Prenda:<input type="text" name="fp" required="required"><br>
    Color: <input type="text" name="color" required="required"><br>
    Tipo: <input type="text" name="tipo" required="required"><br>
    Defectos: <input type="text" name="defectos" required="required"><br>
    Talla: <input type="text" name="talla" required="required"><br>
    Marca: <input type="text" name="marca" required="required"><br> 
    Id del Calendario:  <input type="text" name="ic" required="required"><br>
    <input type="submit" value="Enviar">
                 </center>
             </fieldset>
         </form>
    </body>
</html>

